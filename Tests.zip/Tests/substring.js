const submitButton = document.getElementById('submitString');

document.getElementById('stringInputField').value = '83 12, 40 0E, C8 B4 ,40 16, 04 19, 43 69, 19 9A, 43 69, CC CD, 43 68, 19 9A, 43 69, 80 00, 43 C9, D9 9A, 43 C9, B3 33, 43 C9, 99 9A, 43 CA, 4C CD, 42 47, E1 48, 44 C0, E0 00, 43 F6, 00 00, 43 FE, 8C CD, 44 07, 6C CD, C2 DF, 99 9A, C1 B2, 66 66, C2 7A, CC CD, C1 D5, 99 9A, 44 C2, B9 9A, 43 F8, 26 66, 44 00, F9 9A, 44 08, 60 00, BF 7D, 70 A4, BF 7D, B2 2D, BF 7C, ED 91, BF 7D, F3 B6, 41 08, F5 C3, 3F EC, CC CD, 40 55, C2 8F, 40 57, AE 14, 41 0B, 5C 29, 40 36, 66 66, 40 57, AE 14, 40 5C, CC CD, 3E 19, 99 9A,3F 80, 00 00,3C F5, C2 8F,3D A3, D7 0A ,92 26';


// submitButton.addEventListener('click',()=>{
//      console.log('it works, you clicked me');
//      const textInput = document.getElementById('stringInputField').value;
//      console.log(textInput);
//      let arr = textInput.split(',');
//      let n = 0;
//      arr.forEach(element => {
//           // console.log(n);
//           // console.log(element);
//           arr[n] = element.replaceAll(' ','');
//           // console.log(arr[n]);
//           n = n+1;
//      });
//      console.log(arr);
     
// })

let hexArray = 0;
submitButton.addEventListener('click', handleClick);

function handleClick(){
     console.log('it works, you clicked me');
     const textInput = document.getElementById('stringInputField').value;
     const result = stringToArray(textInput);
     hexArray = result;
     
      let textToLog =  hex64Array(hexArray);
     console.log(textToLog);

     let float = [] ;
     float.length = textToLog.length;
     for (let index = 0; index < textToLog.length; index++) {
          const element = '0x'+textToLog[index];
          float[index] = parseFloat(element);
     }
     console.log(float);
     

     
}
function stringToArray(inputString){
     let arr = inputString.split(',');
     let n = 0;
     arr.forEach(element => {
          arr[n] = element.replaceAll(' ','');
          n = n+1;
     });
     // console.log(arr);
     return arr;
}


function hex64Array(inputArray){
     const length = inputArray.length;
     console.log(length);
     let newArray = [];
     let i = 0;
     newArray.length = length/2;
     console.log(newArray.length);
     let outerIndex = 0;
     for (let index = 0; index < newArray.length; index++) {
          newArray[index] = inputArray[outerIndex+1] + inputArray[outerIndex];
          // console.log(newArray[index]);
          outerIndex += 2;
     }
    
     return newArray;
}

var str = '0x41FC6733';

function parseFloat(str) {
  var float = 0, sign, order, mantiss,exp,
      int = 0, multi = 1;
  if (/^0x/.exec(str)) {
    int = parseInt(str,16);
  }else{
    for (var i = str.length -1; i >=0; i -= 1) {
      if (str.charCodeAt(i)>255) {
        console.log('Wrong string parametr'); 
        return false;
      }
      int += str.charCodeAt(i) * multi;
      multi *= 256;
    }
  }
  sign = (int>>>31)?-1:1;
  exp = (int >>> 23 & 0xff) - 127;
  mantissa = ((int & 0x7fffff) + 0x800000).toString(2);
  for (i=0; i<mantissa.length; i+=1){
    float += parseInt(mantissa[i])? Math.pow(2,exp):0;
    exp--;
  }
  return float*sign;
}




